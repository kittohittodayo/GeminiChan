- あ	- い	- う	- え	- お
a あ	a い	a う	a え	a お
i あ	i い	i う	i え	i お
u あ	u い	u う	u え	u お
e あ	e い	e う	e え	e お
o あ	o い	o う	o え	o お
n あ	n い	n う	n え	n お

- か	- き	- く	- け	- こ
a か	a き	a く	a け	a こ
i か	i き	i く	i け	i こ
u か	u き	u く	u け	u こ
e か	e き	e く	e け	e こ
o か	o き	o く	o け	o こ
n か	n き	n く	n け	n こ

- さ	- し	- す	- せ	- そ
a さ	a し	a す	a せ	a そ
i さ	i し	i す	i せ	i そ
u さ	u し	u す	u せ	u そ
e さ	e し	e す	e せ	e そ
o さ	o し	o す	o せ	o そ
n さ	n し	n す	n せ	n そ

- た	- ち	- つ	- て	- と
a た	a ち	a つ	a て	a と
i た	i ち	i つ	i て	i と
u た	u ち	u つ	u て	u と
e た	e ち	e つ	e て	e と
o た	o ち	o つ	o て	o と
n た	n ち	n つ	n て	n と

- な	- に	- ぬ	- ね	- の
a な	a に	a ぬ	a ね	a の
i な	i に	i ぬ	i ね	i の
u な	u に	u ぬ	u ね	u の
e な	e に	e ぬ	e ね	e の
o な	o に	o ぬ	o ね	o の
n な	n に	n ぬ	n ね	n の

- は	- ひ	- ふ	- へ	- ほ
a は	a ひ	a ふ	a へ	a ほ
i は	i ひ	i ふ	i へ	i ほ
u は	u ひ	u ふ	u へ	u ほ
e は	e ひ	e ふ	e へ	e ほ
o は	o ひ	o ふ	o へ	o ほ
n は	n ひ	n ふ	n へ	n ほ

- ま	- み	- む	- め	- も
a ま	a み	a む	a め	a も
i ま	i み	i む	i め	i も
u ま	u み	u む	u め	u も
e ま	e み	e む	e め	e も
o ま	o み	o む	o め	o も
n ま	n み	n む	n め	n も

- ら	- り	- る	- れ	- ろ
a ら	a り	a る	a れ	a ろ
i ら	i り	i る	i れ	i ろ
u ら	u り	u る	u れ	u ろ
e ら	e り	e る	e れ	e ろ
o ら	o り	o る	o れ	o ろ
n ら	n り	n る	n れ	n ろ

- わ
a わ
i わ
u わ
e わ
o わ
n わ

- や	- ゆ	- よ
a や	a ゆ	a よ
i や	i ゆ	i よ
u や	u ゆ	u よ
e や	e ゆ	e よ
o や	o ゆ	o よ
n や	n ゆ	n よ

- ん
a ん
i ん
u ん
e ん
o ん
n ん

- が	- ぎ	- ぐ	- げ	- ご
a が	a ぎ	a ぐ	a げ	a ご
i が	i ぎ	i ぐ	i げ	i ご
u が	u ぎ	u ぐ	u げ	u ご
e が	e ぎ	e ぐ	e げ	e ご
o が	o ぎ	o ぐ	o げ	o ご
n が	n ぎ	n ぐ	n げ	n ご

- ざ	- じ	- ず	- ぜ	- ぞ
a ざ	a じ	a ず	a ぜ	a ぞ
i ざ	i じ	i ず	i ぜ	i ぞ
u ざ	u じ	u ず	u ぜ	u ぞ
e ざ	e じ	e ず	e ぜ	e ぞ
o ざ	o じ	o ず	o ぜ	o ぞ
n ざ	n じ	n ず	n ぜ	n ぞ

- だ	- で	- ど
a だ	a で	a ど
i だ	i で	i ど
u だ	u で	u ど
e だ	e で	e ど
o だ	o で	o ど
n だ	n で	n ど

- ば	- び	- ぶ	- べ	- ぼ
a ば	a び	a ぶ	a べ	a ぼ
i ば	i び	i ぶ	i べ	i ぼ
u ば	u び	u ぶ	u べ	u ぼ
e ば	e び	e ぶ	e べ	e ぼ
o ば	o び	o ぶ	o べ	o ぼ
n ば	n び	n ぶ	n べ	n ぼ

- ぱ	- ぴ	- ぷ	- ぺ	- ぽ
a ぱ	a ぴ	a ぷ	a ぺ	a ぽ
i ぱ	i ぴ	i ぷ	i ぺ	i ぽ
u ぱ	u ぴ	u ぷ	u ぺ	u ぽ
e ぱ	e ぴ	e ぷ	e ぺ	e ぽ
o ぱ	o ぴ	o ぷ	o ぺ	o ぽ
n ぱ	n ぴ	n ぷ	n ぺ	n ぽ

- きゃ	- きゅ	- きょ
a きゃ	a きゅ	a きょ
i きゃ	i きゅ	i きょ
u きゃ	u きゅ	u きょ
e きゃ	e きゅ	e きょ
o きゃ	o きゅ	o きょ
n きゃ	n きゅ	n きょ

- しゃ	- しゅ	- しょ
a しゃ	a しゅ	a しょ
i しゃ	i しゅ	i しょ
u しゃ	u しゅ	u しょ
e しゃ	e しゅ	e しょ
o しゃ	o しゅ	o しょ
n しゃ	n しゅ	n しょ

- ちゃ	- ちゅ	- ちょ
a ちゃ	a ちゅ	a ちょ
i ちゃ	i ちゅ	i ちょ
u ちゃ	u ちゅ	u ちょ
e ちゃ	e ちゅ	e ちょ
o ちゃ	o ちゅ	o ちょ
n ちゃ	n ちゅ	n ちょ

- にゃ	- にゅ	- にょ
a にゃ	a にゅ	a にょ
i にゃ	i にゅ	i にょ
u にゃ	u にゅ	u にょ
e にゃ	e にゅ	e にょ
o にゃ	o にゅ	o にょ
n にゃ	n にゅ	n にょ

- ひゃ	- ひゅ	- ひょ
a ひゃ	a ひゅ	a ひょ
i ひゃ	i ひゅ	i ひょ
u ひゃ	u ひゅ	u ひょ
e ひゃ	e ひゅ	e ひょ
o ひゃ	o ひゅ	o ひょ
n ひゃ	n ひゅ	n ひょ

- みゃ	- みゅ	- みょ
a みゃ	a みゅ	a みょ
i みゃ	i みゅ	i みょ
u みゃ	u みゅ	u みょ
e みゃ	e みゅ	e みょ
o みゃ	o みゅ	o みょ
n みゃ	n みゅ	n みょ

- りゃ	- りゅ	- りょ
a りゃ	a りゅ	a りょ
i りゃ	i りゅ	i りょ
u りゃ	u りゅ	u りょ
e りゃ	e りゅ	e りょ
o りゃ	o りゅ	o りょ
n りゃ	n りゅ	n りょ

- ぎゃ	- ぎゅ	- ぎょ
a ぎゃ	a ぎゅ	a ぎょ
i ぎゃ	i ぎゅ	i ぎょ
u ぎゃ	u ぎゅ	u ぎょ
e ぎゃ	e ぎゅ	e ぎょ
o ぎゃ	o ぎゅ	o ぎょ
n ぎゃ	n ぎゅ	n ぎょ

- じゃ	- じゅ	- じょ
a じゃ	a じゅ	a じょ
i じゃ	i じゅ	i じょ
u じゃ	u じゅ	u じょ
e じゃ	e じゅ	e じょ
o じゃ	o じゅ	o じょ
n じゃ	n じゅ	n じょ

- びゃ	- びゅ	- びょ
a びゃ	a びゅ	a びょ
i びゃ	i びゅ	i びょ
u びゃ	u びゅ	u びょ
e びゃ	e びゅ	e びょ
o びゃ	o びゅ	o びょ
n びゃ	n びゅ	n びょ

- ぴゃ	- ぴゅ	- ぴょ
a ぴゃ	a ぴゅ	a ぴょ
i ぴゃ	i ぴゅ	i ぴょ
u ぴゃ	u ぴゅ	u ぴょ
e ぴゃ	e ぴゅ	e ぴょ
o ぴゃ	o ぴゅ	o ぴょ
n ぴゃ	n ぴゅ	n ぴょ